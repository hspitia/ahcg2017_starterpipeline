#pragma once
#ifndef HELP_H
#define HELP_H

	#include "SVfinder.h"
	void usage();
	void help();

#endif // HELP_H